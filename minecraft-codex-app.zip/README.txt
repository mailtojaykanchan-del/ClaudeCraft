Minecraft Codex App

Open minecraft-codex.html in Chrome. Keep three.min.js in this folder.
